# NoteKeeper — Product Spec Registry

What the product does, feature by feature, as actually shipped. Each entry is
the durable summary: capability, boundaries, and the contracts future work must
not break. Deep specs live in [prd/archive/](prd/archive/).
Maintained by /finish-feature — append an entry when a feature ships.

## Feature index
| Feature | Area | Since | Spec |
|---|---|---|---|
| Searchbox | Notes | `2222222` | [PRD](prd/archive/searchbox/searchbox.md) |

## Searchbox
**Area:** Notes · **Since:** `1111111..2222222`

**What it does:** Users can search their notes by substring, case-insensitively.

**Boundaries:** No regex, no fuzzy matching.

**Contracts:** `search(q)` in `src/search.py` matches case-insensitively.

**Spec:** [PRD](prd/archive/searchbox/searchbox.md) · [TDD](prd/archive/searchbox/TDD.md)
