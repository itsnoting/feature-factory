# TDD · Searchbox
**Status: AS-BUILT** · 2026-06-20 · shipped `1111111..2222222`
`search(q)` in `src/search.py`; case-insensitive substring.
