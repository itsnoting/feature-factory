# Archive
Shipped specs; active specs live one level up.

| Feature | Shipped |
|---|---|
| [searchbox](./searchbox/searchbox.md) | `1111111..2222222` |
