# PRD: Searchbox
Search notes by substring. Shipped.
