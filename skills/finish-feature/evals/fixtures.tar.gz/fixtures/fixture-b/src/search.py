from tracker import list_notes

def search(q: str) -> list:
    return [n for n in list_notes() if q.lower() in n["text"].lower()]
