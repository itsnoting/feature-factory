"""Session notes (see docs/prd/session-notes)."""
import json, time
from pathlib import Path

NOTE_KIND = "session_note"
STORE = Path(__file__).with_name("notes.json")

def add_note(text: str) -> dict:
    if not text or not text.strip():
        raise ValueError("empty note")
    note = {"kind": NOTE_KIND, "text": text.strip(), "ts": time.time()}
    notes = _load()
    notes.append(note)
    STORE.write_text(json.dumps(notes))
    return note

def list_notes() -> list:
    return sorted(_load(), key=lambda n: n["ts"], reverse=True)

def _load() -> list:
    return json.loads(STORE.read_text()) if STORE.exists() else []

def note_count() -> int:
    return len(_load())
