"""Tiny note-taking CLI (fixture project)."""
from tracker import add_note, list_notes

def main(argv):
    if argv[:1] == ["add"]:
        return add_note(" ".join(argv[1:]))
    return list_notes()
