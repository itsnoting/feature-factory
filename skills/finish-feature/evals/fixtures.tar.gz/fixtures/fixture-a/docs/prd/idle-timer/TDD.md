# TDD · Idle Timer
**PRD:** [idle-timer.md](./idle-timer.md) · **Status:** DRAFT · 2026-07-01

## Architecture
| Layer | File | Pieces |
|---|---|---|
| Logic | `src/idle.py` | `watch`, `IdleWatch`, `IDLE_EVENT_KIND` |
| Tests | `tests/test_idle.py` | gap detection, event emission |
