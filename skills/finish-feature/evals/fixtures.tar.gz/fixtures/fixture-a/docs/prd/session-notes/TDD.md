# TDD · Session Notes
**PRD:** [session-notes.md](./session-notes.md) · **Status:** DRAFT · 2026-06-28

## Architecture
| Layer | File | Pieces |
|---|---|---|
| Logic | `src/tracker.py` | `add_note`, `list_notes`, `NOTE_KIND` |
| Store | `notes.json` | append-only list of note dicts |
| Tests | `tests/test_tracker.py` | rejection, ordering, kind tag |

## Design
- `NOTE_KIND = "session_note"` is the filter contract (PRD R4).
- `add_note` raises `ValueError` on empty/whitespace text (R1).
- Storage is a plain JSON list; newest-first is sorted at read time (R2).
