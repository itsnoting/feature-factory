# PRD: Idle Timer
**Status:** Draft

## Goal
Detect idle gaps longer than 10 minutes and close the session automatically.

## Requirements
- R1 `src/idle.py` exposes `watch(timeout_s)` returning an `IdleWatch`.
- R2 An idle gap emits an `"idle_gap"` event into the session notes.
