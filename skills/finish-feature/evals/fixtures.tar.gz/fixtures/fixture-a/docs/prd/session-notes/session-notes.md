# PRD: Session Notes
**Status:** Draft

## Goal
Users can attach timestamped notes to a work session and list them back.

## Requirements
- R1 `add_note(text)` stores a note with a UTC timestamp; empty text is rejected.
- R2 `list_notes()` returns notes newest-first.
- R3 Notes persist to `notes.json` next to the app.
- R4 Every note dict carries `"kind": "session_note"` for future filtering.

## Non-goals
- No editing or deleting notes (append-only by design).
- No cloud sync.
