import pytest
from src.tracker import add_note, list_notes, NOTE_KIND

def test_rejects_empty():
    with pytest.raises(ValueError):
        add_note("   ")

def test_kind_tag():
    assert NOTE_KIND == "session_note"
